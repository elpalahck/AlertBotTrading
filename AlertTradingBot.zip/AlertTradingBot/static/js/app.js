// TradingView to Telegram Integration - Main JavaScript File

document.addEventListener('DOMContentLoaded', function() {
    // Enable all tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Handle tab selection and URL persistence
    const triggerTabList = document.querySelectorAll('#configTabs button');
    triggerTabList.forEach(function(triggerEl) {
        const tabTrigger = new bootstrap.Tab(triggerEl);
        
        triggerEl.addEventListener('click', function(event) {
            event.preventDefault();
            tabTrigger.show();
            
            // Update URL with the selected tab
            const tabId = triggerEl.getAttribute('id');
            if (tabId === 'alerts-tab') {
                const url = new URL(window.location);
                url.searchParams.set('tab', 'alerts');
                window.history.pushState({}, '', url);
            } else {
                const url = new URL(window.location);
                url.searchParams.delete('tab');
                window.history.pushState({}, '', url);
            }
        });
    });

    // Function to format JSON for display
    window.formatJSON = function(jsonString) {
        try {
            const obj = JSON.parse(jsonString);
            return JSON.stringify(obj, null, 2);
        } catch (e) {
            return jsonString;
        }
    };
});

// Copy webhook URL to clipboard
function copyWebhookUrl(elementId) {
    const element = document.getElementById(elementId);
    element.select();
    document.execCommand('copy');
    
    // Show a temporary success message
    const originalText = element.nextElementSibling.innerHTML;
    element.nextElementSibling.innerHTML = '<i class="fas fa-check"></i> Copied!';
    
    setTimeout(function() {
        element.nextElementSibling.innerHTML = originalText;
    }, 2000);
}
